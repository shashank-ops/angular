export class Names{
    Names=[
        {id:1,name:'Ajay'},
          {id:2,name:'Bunty'},
          {id:3,name:'Chintan'},
          {id:4,name:'Darshan'},
          {id:5,name:'Rakesh'},
          {id:6,name:'Mayank'},
          {id:7,name:'Ramesh'},
          {id:8,name:'Suresh'},
          {id:9,name:'Jay'},
          {id:10,name:'Prem'}
        ]
}

